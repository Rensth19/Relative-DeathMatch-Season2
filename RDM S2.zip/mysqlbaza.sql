-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 05. Mar 2021. u 14:30
-- Server version: 5.7.29
-- PHP Version: 5.6.40-25+0~20200224.31+debian9~1.gbp0b752b

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srv_1089488_pPv`
--

-- --------------------------------------------------------

--
-- Struktura tabele `admin`
--

CREATE TABLE `admin` (
  `adminID` int(11) NOT NULL,
  `adminName` varchar(24) NOT NULL,
  `adminLevel` int(11) NOT NULL,
  `adminCMD` int(11) NOT NULL,
  `adminBan` int(11) NOT NULL,
  `adminUnban` int(11) NOT NULL,
  `adminWarn` int(11) NOT NULL,
  `adminUnwarn` int(11) NOT NULL,
  `adminKick` int(11) NOT NULL,
  `adminJail` int(11) NOT NULL,
  `adminUnjail` int(11) NOT NULL,
  `adminSpec` int(11) NOT NULL,
  `adminHours` int(11) NOT NULL,
  `adminMinutes` int(11) NOT NULL,
  `adminLastLogin` datetime NOT NULL,
  `adminOnline` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Prikaz podataka tabele `admin`
--

INSERT INTO `admin` (`adminID`, `adminName`, `adminLevel`, `adminCMD`, `adminBan`, `adminUnban`, `adminWarn`, `adminUnwarn`, `adminKick`, `adminJail`, `adminUnjail`, `adminSpec`, `adminHours`, `adminMinutes`, `adminLastLogin`, `adminOnline`) VALUES
(1, 'Luyn', 3, 128, 1, 1, 0, 0, 0, 1, 1, 15, 5, 34, '2021-02-15 13:26:19', 0),
(2, 'Huligan', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '2021-02-12 22:31:27', 0),
(3, '1311', 3, 35, 0, 0, 0, 0, 0, 0, 0, 7, 2, 36, '2021-03-04 19:56:50', 0),
(5, 'Boss', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, '2021-02-13 20:58:56', 0),
(6, '1312', 2, 18, 1, 0, 0, 0, 0, 0, 0, 3, 0, 57, '2021-02-18 09:29:59', 0),
(8, 'Huligan', 2, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, '2021-02-14 19:44:13', 0);

-- --------------------------------------------------------

--
-- Struktura tabele `arena`
--

CREATE TABLE `arena` (
  `arenaID` int(11) NOT NULL,
  `arenaName` varchar(24) NOT NULL,
  `arenaWeapon1` int(11) NOT NULL,
  `arenaWeapon2` int(11) NOT NULL,
  `arenaWeapon3` int(11) NOT NULL,
  `arenaIntID` int(11) NOT NULL,
  `arenaVWID` int(11) NOT NULL,
  `arenaX_0` float NOT NULL,
  `arenaY_0` float NOT NULL,
  `arenaZ_0` float NOT NULL,
  `arenaA_0` float NOT NULL,
  `arenaX_1` float NOT NULL,
  `arenaY_1` float NOT NULL,
  `arenaZ_1` float NOT NULL,
  `arenaA_1` float NOT NULL,
  `arenaX_2` float NOT NULL,
  `arenaY_2` float NOT NULL,
  `arenaZ_2` float NOT NULL,
  `arenaA_2` float NOT NULL,
  `arenaX_3` float NOT NULL,
  `arenaY_3` float NOT NULL,
  `arenaZ_3` float NOT NULL,
  `arenaA_3` float NOT NULL,
  `arenaX_4` float NOT NULL,
  `arenaY_4` float NOT NULL,
  `arenaZ_4` float NOT NULL,
  `arenaA_4` float NOT NULL,
  `arenaX_5` float NOT NULL,
  `arenaY_5` float NOT NULL,
  `arenaZ_5` float NOT NULL,
  `arenaA_5` float NOT NULL,
  `arenaX_6` float NOT NULL,
  `arenaY_6` float NOT NULL,
  `arenaZ_6` float NOT NULL,
  `arenaA_6` float NOT NULL,
  `arenaKSRecord` int(11) NOT NULL,
  `arenaKSRecorder` varchar(24) NOT NULL,
  `arenaKillsRecord` int(11) NOT NULL,
  `arenaKillsRecorder` varchar(24) NOT NULL,
  `arenaLocked` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Prikaz podataka tabele `arena`
--

INSERT INTO `arena` (`arenaID`, `arenaName`, `arenaWeapon1`, `arenaWeapon2`, `arenaWeapon3`, `arenaIntID`, `arenaVWID`, `arenaX_0`, `arenaY_0`, `arenaZ_0`, `arenaA_0`, `arenaX_1`, `arenaY_1`, `arenaZ_1`, `arenaA_1`, `arenaX_2`, `arenaY_2`, `arenaZ_2`, `arenaA_2`, `arenaX_3`, `arenaY_3`, `arenaZ_3`, `arenaA_3`, `arenaX_4`, `arenaY_4`, `arenaZ_4`, `arenaA_4`, `arenaX_5`, `arenaY_5`, `arenaZ_5`, `arenaA_5`, `arenaX_6`, `arenaY_6`, `arenaZ_6`, `arenaA_6`, `arenaKSRecord`, `arenaKSRecorder`, `arenaKillsRecord`, `arenaKillsRecorder`, `arenaLocked`) VALUES
(0, 'LVPD', 24, 24, 24, 3, 0, 288.59, 169.611, 1007.17, 274.55, 300.379, 191.683, 1007.17, 91.3915, 267.973, 185.332, 1008.17, 358.018, 238.696, 140.026, 1003.02, 356.137, 209.095, 142.221, 1003.02, 272.163, 189.581, 158.57, 1003.02, 269.084, 189.854, 179.555, 1003.02, 264.386, 10, '1312', 44, 'Petrovic_Redrose', 0),
(1, 'Ghost Town', 24, 33, 24, 0, 0, -382.956, 2273.89, 41.5658, 175.992, -407.524, 2245.36, 42.4297, 181.946, -395.484, 2196.59, 42.4251, 247.746, -366.665, 2187.01, 42.4607, 224.873, -362.225, 2225.54, 42.4844, 316.03, -340.629, 2269.36, 50.7251, 106.745, -429.944, 2233.02, 42.4297, 128.052, 0, 'None', 0, 'None', 0),
(2, 'RC Battlefield', 24, 31, 34, 10, 0, -969.498, 1089.1, 1345.01, 160.372, -973.608, 1073.3, 1345, 160.372, -972.992, 1056.12, 1345.03, 73.8915, -1040.28, 1097.84, 1343.13, 205.493, -1072.91, 1027.96, 1343.12, 352.111, -1136.58, 1030.66, 1345.76, 335.949, -1131.47, 1063.54, 1345.76, 251.193, 11, 'Haskic', 36, 'Haskic', 0),
(3, 'Area 21', 24, 31, 34, 14, 0, -1349.8, 1606.1, 1052.53, 35.5805, -1374.71, 1636.51, 1052.53, 96.7743, -1450.83, 1618.12, 1052.53, 166.242, -1483.35, 1572.14, 1052.53, 313.173, -1493.57, 1629.52, 1052.53, 227.632, -1473.28, 1649.57, 1052.53, 304.435, -1472.85, 1649.48, 1052.53, 242.046, 4, 'silaMrtve_Mujebem', 46, 'Aemala', 0);

-- --------------------------------------------------------

--
-- Struktura tabele `ban`
--

CREATE TABLE `ban` (
  `banName` varchar(24) NOT NULL,
  `banIP` varchar(16) NOT NULL,
  `banAdmin` varchar(24) NOT NULL,
  `banReason` varchar(24) NOT NULL,
  `banDate` datetime NOT NULL,
  `banTime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Prikaz podataka tabele `ban`
--

INSERT INTO `ban` (`banName`, `banIP`, `banAdmin`, `banReason`, `banDate`, `banTime`) VALUES
('Milan_Sreckov', '188.2.225.20', '1312', 'citerko', '2021-02-13 20:16:06', 0),
('Aezakmi', '89.23.72.7', 'Luyn', 'pao proveru', '2021-02-14 19:18:25', 0);

-- --------------------------------------------------------

--
-- Struktura tabele `fame`
--

CREATE TABLE `fame` (
  `fameID` int(11) NOT NULL,
  `fameName` varchar(24) NOT NULL,
  `fameDescription` varchar(256) NOT NULL,
  `fameSkin` int(11) NOT NULL,
  `fameX` float NOT NULL,
  `fameY` float NOT NULL,
  `fameZ` float NOT NULL,
  `fameA` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktura tabele `rank`
--

CREATE TABLE `rank` (
  `rankID` int(11) NOT NULL,
  `rankName` varchar(24) NOT NULL,
  `rankPoint` int(11) NOT NULL,
  `rankReward` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Prikaz podataka tabele `rank`
--

INSERT INTO `rank` (`rankID`, `rankName`, `rankPoint`, `rankReward`) VALUES
(0, 'Newbie', 100, 1000),
(1, 'Trainee', 500, 5000),
(2, 'Average', 1000, 10000),
(3, 'Master', 10000, 100000),
(4, 'Legend', 50000, 500000),
(5, 'God', 100000, 1000000);

-- --------------------------------------------------------

--
-- Struktura tabele `server-info`
--

CREATE TABLE `server-info` (
  `serverPoseta` int(11) NOT NULL,
  `serverRecord` int(11) NOT NULL,
  `serverUpozorenih` int(11) NOT NULL,
  `serverKikovanih` int(11) NOT NULL,
  `serverBanovanih` int(11) NOT NULL,
  `serverUsers` int(11) NOT NULL,
  `serverWhitelisted` int(11) NOT NULL,
  `serverRegistration` tinyint(1) NOT NULL,
  `serverWL` tinyint(1) NOT NULL,
  `serverName1` varchar(72) NOT NULL,
  `serverName2` varchar(72) NOT NULL,
  `serverArena` tinyint(1) NOT NULL,
  `serverDuel` tinyint(1) NOT NULL,
  `serverVersus` tinyint(1) NOT NULL,
  `versusWeapon` int(11) NOT NULL,
  `serverFreeroam` tinyint(1) NOT NULL,
  `dayID` int(11) NOT NULL,
  `dayKills` int(11) NOT NULL,
  `monthKills` int(11) NOT NULL,
  `monthID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Prikaz podataka tabele `server-info`
--

INSERT INTO `server-info` (`serverPoseta`, `serverRecord`, `serverUpozorenih`, `serverKikovanih`, `serverBanovanih`, `serverUsers`, `serverWhitelisted`, `serverRegistration`, `serverWL`, `serverName1`, `serverName2`, `serverArena`, `serverDuel`, `serverVersus`, `versusWeapon`, `serverFreeroam`, `dayID`, `dayKills`, `monthKills`, `monthID`) VALUES
(173, 12, 0, 42, 2, 71, 0, 1, 0, 'C3.RS DM - Welcome', 'C3.RS DM - Welcome', 1, 1, 1, 24, 0, 1, 0, 0, 1);

-- --------------------------------------------------------

--
-- Struktura tabele `user`
--

CREATE TABLE `user` (
  `pID` int(11) NOT NULL,
  `pName` varchar(24) NOT NULL,
  `pIP` varchar(16) NOT NULL,
  `pPassword` varchar(65) NOT NULL,
  `pSex` tinyint(1) NOT NULL,
  `pRegDate` datetime NOT NULL,
  `pLastLogin` datetime NOT NULL,
  `pOnline` tinyint(1) NOT NULL,
  `pHours` int(11) NOT NULL,
  `pMinutes` int(11) NOT NULL,
  `pAdmin` int(11) NOT NULL,
  `pAdminCode` int(11) NOT NULL,
  `pPremium` tinyint(1) NOT NULL,
  `pPremiumHours` int(11) NOT NULL,
  `pJail` int(11) NOT NULL,
  `pJailReason` varchar(16) NOT NULL,
  `pMute` int(11) NOT NULL,
  `pMuteReason` varchar(16) NOT NULL,
  `pWarn` int(11) NOT NULL,
  `pSkinID` int(11) NOT NULL,
  `pKills` int(11) NOT NULL,
  `pDeaths` int(11) NOT NULL,
  `pMaxKS` int(11) NOT NULL,
  `pMoney` int(11) NOT NULL,
  `pDayKills` int(11) NOT NULL,
  `pDayDeaths` int(11) NOT NULL,
  `pDayWins` int(11) NOT NULL,
  `pMonthKills` int(11) NOT NULL,
  `pMonthDeaths` int(11) NOT NULL,
  `pMonthWins` int(11) NOT NULL,
  `pRank` int(11) NOT NULL DEFAULT '-1',
  `pArenaKills` int(11) NOT NULL,
  `pArenaDeaths` int(11) NOT NULL,
  `pDuelWins` int(11) NOT NULL,
  `pDuelDefeats` int(11) NOT NULL,
  `pVersusWins` int(11) NOT NULL,
  `pVersusDefeats` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Prikaz podataka tabele `user`
--

INSERT INTO `user` (`pID`, `pName`, `pIP`, `pPassword`, `pSex`, `pRegDate`, `pLastLogin`, `pOnline`, `pHours`, `pMinutes`, `pAdmin`, `pAdminCode`, `pPremium`, `pPremiumHours`, `pJail`, `pJailReason`, `pMute`, `pMuteReason`, `pWarn`, `pSkinID`, `pKills`, `pDeaths`, `pMaxKS`, `pMoney`, `pDayKills`, `pDayDeaths`, `pDayWins`, `pMonthKills`, `pMonthDeaths`, `pMonthWins`, `pRank`, `pArenaKills`, `pArenaDeaths`, `pDuelWins`, `pDuelDefeats`, `pVersusWins`, `pVersusDefeats`) VALUES
(1, 'Luyn', '77.243.23.134', 'E5AA9D9A708C46DC8C81BF111FB538C8BFACC6F3576CC40E3EC797BE1175C97B', 1, '2021-02-12 21:43:48', '2021-02-12 21:43:48', 1, 4, 37, 3, 21245, 1, 397, 0, 'None', 0, '', 0, 292, 509, 63, 0, 0, 0, 0, 14, 0, 0, 0, -1, 30, 155, 0, 0, 0, 0),
(3, '1311', '109.245.39.80', 'AE35E5A0C776AA0B8C9880D47DAB5E18873127F6D36E8C25DFB08094AF42B100', 1, '2021-02-13 16:25:03', '2021-02-13 16:25:03', 1, 2, 36, 3, 1337, 0, 0, 0, '', 0, '', 0, 293, 14, 30, 0, 0, 0, 0, 0, 0, 0, 0, -1, 14, 29, 0, 0, 0, 0),
(4, '1312', '188.120.98.232', '80E3661D193A0AE9B475870509D3BBEB1CFF75E7A736D7D3DA22F3E4E7B7391D', 1, '2021-02-13 19:40:39', '2021-02-13 19:40:39', 1, 1, 56, 2, 1312, 0, 0, 0, '', 0, '', 0, 212, 10905, 73, 0, -1000, 0, 0, 2, 0, 0, 1, 0, 154, 73, 3, 0, 0, 0),
(5, 'Boss', '87.116.177.37', '8D969EEF6ECAD3C29A3A629280E686CF0C3F5D5A86AFF3CA12020C923ADC6C92', 1, '2021-02-13 19:48:09', '2021-02-13 19:48:09', 1, 0, 15, 2, 123, 0, 0, 0, '', 0, '', 0, 23, 1, 11, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 11, 0, 0, 0, 0),
(6, 'khz', '62.4.55.248', '5624C771A8E2E0C12FB764264E91B321FAFAF81178DE928864F843BDF194E155', 1, '2021-02-13 20:03:20', '2021-02-13 20:03:20', 1, 0, 31, 0, 0, 0, 0, 0, '', 0, '', 0, 294, 60, 28, 0, 0, 0, 0, 0, 0, 0, 0, -1, 60, 27, 0, 0, 0, 0),
(7, 'teblerone_Redrose', '91.148.99.9', 'C051C4DF5E6FAA964524F42DD844C4A40A45855AF04EAB901DE73B7DDB83563F', 1, '2021-02-13 20:10:35', '2021-02-13 20:10:35', 1, 0, 20, 0, 0, 0, 0, 0, '', 0, '', 0, 230, 19, 25, 0, 0, 0, 0, 0, 0, 0, 0, -1, 19, 25, 0, 0, 0, 0),
(8, 'Dagllas', '87.116.190.224', 'C051C4DF5E6FAA964524F42DD844C4A40A45855AF04EAB901DE73B7DDB83563F', 1, '2021-02-13 20:10:50', '2021-02-13 20:10:50', 1, 0, 18, 0, 0, 0, 0, 0, '', 0, '', 0, 294, 28, 35, 0, 0, 0, 0, 0, 0, 0, 0, -1, 28, 35, 0, 0, 0, 0),
(9, 'Dzek', '188.2.220.69', 'F8FF845DF65118AE570FBC17C810EB6909B975186CFD0DC898908C0F1286C648', 1, '2021-02-13 20:10:52', '2021-02-13 20:10:52', 1, 0, 23, 0, 0, 0, 0, 0, '', 0, '', 0, 230, 44, 35, 0, 0, 0, 0, 0, 0, 0, 0, -1, 44, 35, 0, 0, 0, 0),
(10, 'Milan_Sreckov', '188.2.225.20', '14F89E0C4C9DB417E8D22904EDD233F9DFFDA954AB1FB0164AFFD953F8433398', 1, '2021-02-13 20:11:10', '2021-02-13 20:11:10', 1, 0, 4, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 5, 0, 0, 0, 0),
(11, 'Bajkos', '178.221.228.30', 'C051C4DF5E6FAA964524F42DD844C4A40A45855AF04EAB901DE73B7DDB83563F', 1, '2021-02-13 20:11:35', '2021-02-13 20:11:35', 1, 0, 11, 0, 0, 0, 0, 0, '', 0, '', 0, 303, 11, 17, 0, 0, 0, 0, 0, 0, 0, 0, -1, 11, 17, 0, 0, 0, 0),
(12, 'Petrovic_Redrose', '31.223.143.226', 'A8858CCBE26558E6383AC4D06641EAD8D3CB3B5682F23F30108E68BD39C7BE18', 1, '2021-02-13 20:11:49', '2021-02-13 20:11:49', 1, 0, 19, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 44, 26, 0, 0, 0, 0, 0, 0, 0, 0, -1, 44, 26, 0, 0, 0, 0),
(13, 'Rose', '5.43.106.31', 'DE270E80DF9E2CF9AE4AF5863A4041265BCD1519D6901AF60DF7941F073BF8F1', 1, '2021-02-13 20:15:06', '2021-02-13 20:15:06', 1, 0, 3, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 2, 7, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, 7, 0, 0, 0, 0),
(14, 'Savke', '178.221.185.22', '5FD924625F6AB16A19CC9807C7C506AE1813490E4BA675F843D5A10E0BAACDB8', 1, '2021-02-13 20:23:43', '2021-02-13 20:23:43', 1, 0, 2, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 4, 3, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, 3, 0, 0, 0, 0),
(15, 'Balex', '178.220.209.116', '60B949AF6BC2BD60EEEF5F3F3F5E4E9F6A8CDB7FA854E3B3476C659117086EF4', 1, '2021-02-13 20:24:02', '2021-02-13 20:24:02', 1, 0, 3, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(16, 'Markovic', '89.146.188.204', 'A320480F534776BDDB5CDB54B1E93D210A3C7D199E80A23C1B2178497B184C76', 1, '2021-02-13 20:24:17', '2021-02-13 20:24:17', 1, 0, 3, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0),
(17, 'oggy', '109.245.191.204', '177F6DB6F9E7A80F84B36DE3229E2B5EBB9C23888A5332E021356F4EE1645DCF', 1, '2021-02-13 20:40:53', '2021-02-13 20:40:53', 1, 0, 19, 0, 0, 0, 0, 0, '', 0, '', 0, 132, 32, 14, 0, 0, 0, 0, 0, 0, 0, 0, -1, 32, 14, 0, 0, 0, 0),
(18, 'Ksalazi_Dazai', '45.93.93.44', '96CAE35CE8A9B0244178BF28E4966C2CE1B8385723A96A6B838858CDD6CA0A1E', 1, '2021-02-13 20:56:32', '2021-02-13 20:56:32', 1, 0, 10, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 3, 7, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 7, 0, 0, 0, 0),
(19, 'c0a', '178.79.51.39', 'B51E06540FF5063FA2F70ADA88D16A17CA0E111DCFAD02C7AF255931892AF48F', 1, '2021-02-13 21:01:44', '2021-02-13 21:01:44', 1, 0, 57, 0, 0, 0, 0, 0, '', 0, '', 0, 230, 21, 3, 0, 0, 0, 0, 0, 0, 0, 0, -1, 21, 3, 0, 0, 0, 0),
(20, 'HASKICH69', '178.236.90.24', '7E65256F9A45750AA1B3EA04F00BA4B92CE9D35AAC4D801C09445D6F9AA07927', 1, '2021-02-13 21:07:55', '2021-02-13 21:07:55', 1, 0, 17, 0, 0, 0, 0, 0, '', 0, '', 0, 44, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, 3, 0, 0, 0, 0),
(21, 'Aezakmi', '89.23.72.7', 'DACCD65C913325C75FB9B4D74C53D6A8741C26767E765516BC0B30E84C79E2AE', 1, '2021-02-14 19:01:00', '2021-02-14 19:01:00', 1, 0, 15, 0, 0, 0, 0, 0, '', 0, '', 0, 230, 24, 21, 0, 0, 0, 0, 0, 0, 0, 0, -1, 24, 21, 0, 0, 0, 0),
(22, 'Kamenko', '217.71.60.34', '96CAE35CE8A9B0244178BF28E4966C2CE1B8385723A96A6B838858CDD6CA0A1E', 1, '2021-02-14 19:01:29', '2021-02-14 19:01:29', 1, 0, 52, 0, 0, 0, 0, 0, '', 0, '', 0, 136, 28, 36, 0, 0, 0, 0, 0, 0, 0, 0, -1, 28, 36, 0, 0, 0, 0),
(23, 'Jack_RedRose', '188.2.220.69', 'A203FB2890D0893932915AFD5E72436AC6D51E0D412385FC621276B42AE806B7', 1, '2021-02-14 19:01:43', '2021-02-14 19:01:43', 1, 0, 42, 0, 0, 0, 0, 0, '', 0, '', 0, 294, 16, 15, 0, 0, 0, 0, 0, 0, 0, 0, -1, 16, 15, 0, 0, 0, 0),
(24, 'Huligan', '213.196.86.77', 'E1A4F5EF8C4CC1FBED6C1961E2667612D16CD2C5C43F8463984A0823F1B3FA26', 1, '2021-02-14 19:02:56', '2021-02-14 19:02:56', 1, 0, 18, 2, 3454, 0, 0, 0, '', 0, '', 0, 23, 8, 10, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, 10, 0, 0, 0, 0),
(25, 'digimon', '45.93.93.111', '96CAE35CE8A9B0244178BF28E4966C2CE1B8385723A96A6B838858CDD6CA0A1E', 1, '2021-02-14 19:06:39', '2021-02-14 19:06:39', 1, 0, 4, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 2, 0, 0, 0, 0),
(26, 'Jamal_Vincent', '178.77.18.130', '6B4AECFCDB70CB2AABED4D6EC98FE9B15C74B27D5D000B1C61424ABD61FC70F8', 1, '2021-02-14 19:11:13', '2021-02-14 19:11:13', 1, 0, 8, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(27, 'Ognjen_RedRose', '37.220.76.67', '61B9D3AC1106F4958D2CDED27B853566D90C04BFAEA0CA00567AB6FB4BB5526A', 1, '2021-02-14 19:27:23', '2021-02-14 19:27:23', 1, 0, 3, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 4, 2, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, 2, 0, 0, 0, 0),
(28, 'Lucas', '94.253.238.47', 'CC52DDCC4FB020841F26D830E8B8CD6E60D7AB56F9771252A3417E92E8C23966', 1, '2021-02-14 19:36:08', '2021-02-14 19:36:08', 1, 0, 19, 0, 0, 0, 0, 0, '', 0, '', 0, 199, 21, 16, 0, 0, 0, 0, 0, 0, 0, 0, -1, 21, 16, 0, 0, 0, 0),
(29, 'DRAZEN', '24.135.115.91', '12AC59C03D72797127D1F57F22DD357B8219E9E158057C36B9EE8EED1322BED3', 1, '2021-02-14 20:37:27', '2021-02-14 20:37:27', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 180, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(30, 'Haskic', '178.236.90.24', 'CEFB3D2C642378CF1166A0505A50518C6EE802ECF6E239B76DC8368E2041FA23', 1, '2021-02-14 20:52:48', '2021-02-14 20:52:48', 1, 1, 15, 0, 0, 0, 0, 0, '', 0, '', 0, 137, 60, 38, 0, 0, 0, 0, 1, 0, 0, 0, -1, 60, 38, 0, 0, 0, 0),
(31, 'Marko_Mirkovic', '109.175.107.52', '6A71CFBA57A28D8811BD015829555C92430E8C466448DEEABB7CABF6E51BD8F8', 1, '2021-02-14 21:18:30', '2021-02-14 21:18:30', 1, 0, 5, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(32, 'Maid_Halilcevic', '109.175.105.70', 'F9815527A826FE622DB5DB8A6585E377F5CCEE16D2A52104797E449B62B74C4C', 1, '2021-02-14 21:19:50', '2021-02-14 21:19:50', 1, 0, 11, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(33, 'Sanco', '31.223.131.52', '1CDA6879DC9D1C95A222F20B67DEFE172A380C00C76F812916A90FE0AA629FC2', 1, '2021-02-14 21:21:54', '2021-02-14 21:21:54', 1, 0, 6, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 4, 11, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, 11, 0, 0, 0, 0),
(34, 'yrb', '79.140.150.79', 'E6ADB338026671EBDBD1A2BE086A221CAB3575DEA4EC2D7F7B015126F332168E', 1, '2021-02-14 21:25:35', '2021-02-14 21:25:35', 1, 0, 4, 0, 0, 0, 0, 0, '', 0, '', 0, 32, 8, 3, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, 3, 0, 0, 0, 0),
(35, 'SKRR', '95.168.121.37', '8E987DFE4154119D9D96A885975B79593F5D9CD2A63B5E925A1E3E903DCABCA5', 1, '2021-02-15 08:58:13', '2021-02-15 08:58:13', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 137, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(36, 'Dusan_Scofieldd', '87.116.190.168', '8BB0CF6EB9B17D0F7D22B456F121257DC1254E1F01665370476383EA776DF414', 0, '2021-02-15 09:49:30', '2021-02-15 09:49:30', 1, 0, 0, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(37, 'Lazar_Kokic', '77.243.27.34', '6C25670CBBB5C7323DBCCB3E2284A8094B7E25196D1066DCBAD223C1BD9D6308', 1, '2021-02-15 13:25:02', '2021-02-15 13:25:02', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(38, 'Dilli', '77.77.217.86', '6BD48D78F217D8E40E4872BBA0A9C347EB3B588780CE48D1D9AEEB696E525749', 1, '2021-02-15 16:45:36', '2021-02-15 16:45:36', 1, 1, 46, 0, 0, 0, 0, 0, '', 0, '', 0, 109, 95, 98, 0, 0, 0, 0, 2, 0, 0, 0, -1, 94, 98, 1, 0, 0, 0),
(39, 'miha', '109.93.213.1', '8D969EEF6ECAD3C29A3A629280E686CF0C3F5D5A86AFF3CA12020C923ADC6C92', 1, '2021-02-15 16:49:00', '2021-02-15 16:49:00', 1, 0, 15, 0, 0, 0, 0, 0, '', 0, '', 0, 120, 22, 14, 0, 0, 0, 0, 1, 0, 0, 0, -1, 22, 14, 0, 0, 0, 0),
(40, 'Cora_Makaveli', '89.110.232.30', '6532EAF41C1453E8EC279A537C032E21FFAB24995F43D2321695A9F4B66383A5', 1, '2021-02-15 16:50:27', '2021-02-15 16:50:27', 1, 0, 8, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 3, 8, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 7, 0, 1, 0, 0),
(41, 'ko.exe', '109.93.191.61', '15E2B0D3C33891EBB0F1EF609EC419420C20E320CE94C65FBC8C3312448EB225', 1, '2021-02-15 17:52:52', '2021-02-15 17:52:52', 1, 0, 3, 0, 0, 0, 0, 0, '', 0, '', 0, 4, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 3, 0, 0),
(42, 'Aychan_Nelson', '5.43.116.17', '5CDE7D9C71CD3BA5A6224DBC54391614AE5A4091AC19115FFB47BB32631C4883', 1, '2021-02-15 18:34:14', '2021-02-15 18:34:14', 1, 0, 0, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(43, 'Harun_hary', '77.78.254.162', '5A00281E963A9BAD22A3788FE0EB19844F7AE0F2F9686E4D3BBF0C46465FA41A', 1, '2021-02-15 19:34:50', '2021-02-15 19:34:50', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(44, 'Alex_Stojilkovic', '80.243.235.141', '797D60FA2F0450AFCAD62994E2234649FD2A37D5747F340F236A43B7EC62296C', 1, '2021-02-16 10:07:10', '2021-02-16 10:07:10', 1, 0, 0, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(45, 'Harun_Hercou', '109.163.131.252', '501AFCADE5875940FF60F8A7AAEB661A7A7BEC4E6FF144F279F07A374FDC9664', 1, '2021-02-16 10:59:02', '2021-02-16 10:59:02', 1, 0, 2, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(46, 'Emin_Herco', '109.163.131.252', '466C40F494C43CB86B34C870D9B55B7181626B373145676AD71211A308374E3B', 1, '2021-02-16 11:00:24', '2021-02-16 11:00:24', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(47, 'Corelli_Basic', '89.111.197.11', '1AB5050E2530A5314BC8C40AF5736D77760383B4E05A8E785C7E1FA06E95327B', 1, '2021-02-16 13:49:42', '2021-02-16 13:49:42', 1, 0, 3, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(48, 'hecim', '188.2.158.65', '3097C24BF1DAF818D9FDF2803A4E88C6D7BBF68A54C8483582C90BB94208FCCB', 1, '2021-02-16 16:10:40', '2021-02-16 16:10:40', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(49, 'silaMrtve_Mujebem', '109.93.213.1', '8BB0CF6EB9B17D0F7D22B456F121257DC1254E1F01665370476383EA776DF414', 1, '2021-02-16 20:44:40', '2021-02-16 20:44:40', 1, 0, 26, 0, 0, 0, 0, 0, '', 0, '', 0, 120, 16, 12, 0, 0, 0, 0, 0, 0, 0, 0, -1, 16, 12, 0, 0, 0, 0),
(50, 'JASKOMAJKUMRTVU', '109.93.213.1', 'AF71FFB8E3554DD6063574E2E286F5B10BB27FB65D82A4DDE3593FEB851F0030', 1, '2021-02-16 21:13:23', '2021-03-04 19:56:50', 1, 0, 11, 0, 0, 0, 0, 0, '', 0, '', 0, 120, 10, 7, 0, 0, 0, 0, 0, 0, 0, 0, -1, 10, 7, 0, 0, 0, 0),
(51, 'Wolf_Strets', '109.175.97.228', 'E0473D091E2AFAF8357131C65AC0CFF255DCE190031274190EFFB1843E37E095', 1, '2021-02-17 09:23:13', '2021-02-17 09:23:13', 1, 1, 10, 0, 0, 0, 0, 0, '', 0, '', 0, 137, 66, 77, 0, 0, 0, 0, 0, 0, 0, 0, -1, 63, 75, 3, 2, 0, 0),
(52, 'Glisha', '83.131.251.48', 'F9E8153CB2DAD09C06931F941C090009720D7C664B83CAF79168F4E668E65C15', 1, '2021-02-17 09:32:23', '2021-02-17 09:32:23', 1, 0, 5, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, 4, 0, 0, 0, 0),
(53, 'Armin', '77.78.247.128', '5EA962305BEA4AFECACDE8DC8C2F9B5F6350070F725F41664D635DAED52A2BC2', 1, '2021-02-17 09:37:07', '2021-02-17 09:37:07', 1, 0, 14, 0, 0, 0, 0, 0, '', 0, '', 0, 229, 12, 20, 0, 0, 0, 0, 0, 0, 0, 0, -1, 12, 20, 0, 0, 0, 0),
(54, 'Zile_Corelli', '87.116.161.94', 'B0441FDE3B72FDA38C56DC6245CAA185331A01CA86D99FBF57431CA5E787DC4C', 1, '2021-02-17 10:46:29', '2021-02-17 10:46:29', 1, 0, 32, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 27, 43, 0, 0, 0, 0, 0, 0, 0, 0, -1, 25, 40, 2, 3, 0, 0),
(55, 'Filip_Suarez', '178.11.224.157', '96CAE35CE8A9B0244178BF28E4966C2CE1B8385723A96A6B838858CDD6CA0A1E', 1, '2021-02-17 18:54:35', '2021-02-17 18:54:35', 1, 0, 7, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 10, 6, 0, 0, 0, 0, 0, 0, 0, 0, -1, 10, 6, 0, 0, 0, 0),
(56, 'El_Efendija', '77.77.217.86', '3D732729E69ADC59CB6A14D95965B7F1C811F28146EF06445B058FAF4AE94971', 0, '2021-02-17 19:55:00', '2021-02-17 19:55:00', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(57, 'Aemala', '109.93.213.1', '8BB0CF6EB9B17D0F7D22B456F121257DC1254E1F01665370476383EA776DF414', 1, '2021-02-17 20:34:49', '2021-02-17 20:34:49', 1, 0, 37, 0, 0, 0, 0, 0, '', 0, '', 0, 120, 46, 35, 0, 0, 0, 0, 0, 0, 0, 0, -1, 46, 35, 0, 0, 0, 0),
(58, 'Miha_Nelson', '109.93.213.1', '77E0D5BBE4F49B2116A9EB1CFDB572C277085BCD4AF929614CE9226361283742', 1, '2021-02-17 21:17:11', '2021-02-17 21:17:11', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 2, 0, 0, 0, 0),
(59, 'NelsonDME', '178.236.90.24', '96CAE35CE8A9B0244178BF28E4966C2CE1B8385723A96A6B838858CDD6CA0A1E', 1, '2021-02-18 09:09:00', '2021-02-18 09:09:00', 1, 0, 16, 0, 0, 0, 0, 0, '', 0, '', 0, 44, 13, 19, 0, 0, 0, 0, 0, 0, 0, 0, -1, 13, 19, 0, 0, 0, 0),
(60, 'eman', '77.77.223.65', 'A717D9C9DEF3F78D5D983580F0F8BC2DA04B3A6365BD1714E7089DD1D390DEDE', 1, '2021-02-18 20:31:40', '2021-02-18 20:31:40', 1, 0, 4, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(61, 'Arijan007', '62.4.55.7', '30E6BF6ECC39DFDEFA8C25E9F8935A6AD33BC637C489398CAD90829EB9CD074E', 1, '2021-02-19 16:16:38', '2021-02-19 16:16:38', 1, 0, 2, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(62, 'Sparta', '188.120.119.17', 'FD75651436C1063DE8089BA4C48C5DA6E0A0497A826364024ADA9CE400A531B1', 1, '2021-02-21 14:34:34', '2021-02-21 14:34:34', 1, 0, 4, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(63, 'Ramo_Huntly', '109.163.147.241', '2D8043968B404EDF04DFED0FE0BCD0A3DFED89ECD4C8774E4734ACF7C1AC2AB8', 1, '2021-02-21 20:10:41', '2021-02-21 20:10:41', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(64, 'Pavle_Stojankovic', '188.120.116.140', 'B69BFB7E9F5307CE2A97C1B7AF699AA1A816882287016084EC1C35BFDF93E101', 1, '2021-02-23 02:28:22', '2021-02-23 02:28:22', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(65, 'Pavel_Castello', '77.28.67.135', '84234C5CDB5F01ED19335C233FC56846C882B1951C749974DDCB297EC210CC9C', 1, '2021-02-23 13:32:55', '2021-02-23 13:32:55', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(66, 'Aras_Sukurica', '62.4.55.231', '076D2ACFB50F63F438A96107D3E276E7FC1675AC587141ADC0256882B955A316', 1, '2021-02-24 16:13:01', '2021-02-24 16:13:01', 1, 0, 0, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(67, 'Clark_Cappone', '109.175.100.240', '63D598A149AC470ABD310718A263D34EADB6A210EF704DBE3A3D3612AE9760AF', 1, '2021-02-25 21:23:45', '2021-02-25 21:23:45', 1, 0, 0, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(68, 'Anel_Djogic', '109.94.105.40', '0335A474D3324ADF5BB3B29385E635A1157E71B3A733C8D5F8E55C3B62DA1A28', 1, '2021-03-01 15:07:28', '2021-03-01 15:07:28', 1, 0, 2, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(69, 'Luka_Matasic', '212.15.177.78', '225BDAC07A26793F4F9DD0B495E711FCEC4880EFE8BC6B4DAFA8CAFCFD8C2EF4', 1, '2021-03-01 22:46:39', '2021-03-01 22:46:39', 1, 0, 0, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(70, 'Emrah_Arkadas', '77.77.219.165', 'A8E0C30EB08CB172597765A477F225CFAEFA4B9668ACCABEB2EE6ACBA924EB5A', 1, '2021-03-01 23:06:16', '2021-03-01 23:06:16', 1, 0, 2, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0),
(71, 'Kenna_Castellano', '109.237.32.74', '19215C9E7CD9734A648EB5366D78EC9A51C89911843913F9783077B33FBF1F5A', 1, '2021-03-04 19:55:07', '2021-03-04 19:55:07', 1, 0, 2, 0, 0, 0, 0, 0, '', 0, '', 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktura tabele `whitelist`
--

CREATE TABLE `whitelist` (
  `wlID` int(11) NOT NULL,
  `wlName` varchar(24) NOT NULL,
  `wlIP` varchar(16) NOT NULL,
  `wlEmail` varchar(48) NOT NULL,
  `wlDiscord` varchar(32) NOT NULL,
  `wlDiscriminator` varchar(5) NOT NULL,
  `wlStatus` float NOT NULL,
  `wlAdmin` varchar(24) NOT NULL DEFAULT 'None'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `arena`
--
ALTER TABLE `arena`
  ADD PRIMARY KEY (`arenaID`);

--
-- Indexes for table `fame`
--
ALTER TABLE `fame`
  ADD PRIMARY KEY (`fameID`);

--
-- Indexes for table `rank`
--
ALTER TABLE `rank`
  ADD PRIMARY KEY (`rankID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`pID`);

--
-- Indexes for table `whitelist`
--
ALTER TABLE `whitelist`
  ADD PRIMARY KEY (`wlID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `pID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT for table `whitelist`
--
ALTER TABLE `whitelist`
  MODIFY `wlID` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
