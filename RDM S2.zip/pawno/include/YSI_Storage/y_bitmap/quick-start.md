# Quick Start

y_bitmap, unsurprisingly, allows you to write bitmaps (it doesn't currently read them in).  This can
be used to dump visual information.  We will first present a full example, then go through it in
detail.

## Full Example

```pawn
#include <YSI_Storage\y_bitmap>

Generate



```

## Details




