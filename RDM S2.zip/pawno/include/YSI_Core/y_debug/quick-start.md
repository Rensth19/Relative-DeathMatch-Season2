Debug levels:

`Debug_Print1` - Public (callback/timer) called.
`Debug_Print2` - API function (`stock`/none) called.
`Debug_Print3` - Internal function (`static`) called.
`Debug_Print4` - **y_utils** function called.
`Debug_Print5` - Extra debug lines within a function (outside loops).
`Debug_Print6` - Extra debug lines within a loop.
`Debug_Print7` - **y_amx** and **y_cell** functions called.

